from tkinter import *

win = Tk()
win.geometry("300x200+800+50")

win.rowconfigure(0, weight=1)
win.columnconfigure(0, weight=1)
win.title("windows")
canvas=Canvas(win, bg='white')
canvas.grid(sticky='nesw')

def size(event):
    width, heigth = canvas.winfo_width(), canvas.winfo_height()
    print('Canvas size:', width, 'x', heigth)
    items = canvas.find_withtag('all')  # Find all widgets on canvas
    for item in items:
        pass    # Change widget size here, one widget at a time

win.bind('<Configure>', size)   # Hook window size changes

win.mainloop()